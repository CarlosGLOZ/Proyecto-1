function redirigir(url) {
    window.location.href = url;
}