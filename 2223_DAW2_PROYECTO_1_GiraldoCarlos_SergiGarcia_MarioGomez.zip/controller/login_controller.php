<?php
require_once '../config/config.php';

// Llamar a pagina
$entrada_valida = true;
require_once '../view/login.php';